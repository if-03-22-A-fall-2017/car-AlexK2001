#include<stdio.h>

int main(int argc, char const *argv[]) {
  /* code */
  return 0;
}
